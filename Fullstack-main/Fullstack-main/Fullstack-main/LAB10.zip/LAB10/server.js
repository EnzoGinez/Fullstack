const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

const db = new sqlite3.Database('./concessionaria.sqlite');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, login TEXT, senha TEXT)`);
    db.run(`CREATE TABLE IF NOT EXISTS carros (id INTEGER PRIMARY KEY AUTOINCREMENT, marca TEXT, modelo TEXT, ano INTEGER, qtde_disponivel INTEGER)`);
});

app.get('/', (req, res) => {
    res.render('auth');
});

app.post('/usuarios/cadastrar', (req, res) => {
    const { nome, login, senha } = req.body;
    db.run(`INSERT INTO usuarios (nome, login, senha) VALUES (?, ?, ?)`, [nome, login, senha], () => {
        res.redirect('/');
    });
});

app.post('/login', (req, res) => {
    res.redirect('/carros');
});

app.get('/carros', (req, res) => {
    db.all(`SELECT * FROM carros`, [], (err, rows) => {
        res.render('carros', { carros: rows });
    });
});

app.post('/carros/cadastrar', (req, res) => {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    db.run(`INSERT INTO carros (marca, modelo, ano, qtde_disponivel) VALUES (?, ?, ?, ?)`, 
    [marca, modelo, ano, qtde_disponivel], () => {
        res.redirect('/carros');
    });
});

app.post('/carros/vender/:id', (req, res) => {
    db.run(`UPDATE carros SET qtde_disponivel = qtde_disponivel - 1 WHERE id = ? AND qtde_disponivel > 0`, 
    [req.params.id], () => {
        res.redirect('/carros');
    });
});

app.post('/carros/remover/:id', (req, res) => {
    db.run(`DELETE FROM carros WHERE id = ?`, [req.params.id], () => {
        res.redirect('/carros');
    });
});

app.listen(80, () => {
    console.log("Servidor Rodando na porta 80!");
});